﻿using UnityEngine;
using System.Collections;

public class ControlCamera : MonoBehaviour {

	public GameObject player;
	private Vector3 offset;


	// Use this for initialization
	void Start () {
		offset = transform.position - player.transform.position; // this finds the difference between the camera position and the player's position
	}

	// A more reliable Late Update function to call the movement of the camera is called once per frame
	void LateUpdate () {
		transform.position = player.transform.position + offset; // this moves the camera as the ball moves before the next frame
	}
}
