﻿using UnityEngine;
using System.Collections;

public class Movement : MonoBehaviour {

	
	// Update is called once per frame
	void Update () {
		transform.Rotate (new Vector3 (15, 30, 45) * Time.deltaTime); // the pick-ups when not collected, keep rotating using the x,y,z values
	}
}
